cd T1-SDM/projects/TTrack_v1
source venv/bin/activate
python main.py